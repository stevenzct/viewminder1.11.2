﻿namespace viewminder1
{
    partial class superAdmn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2ControlBox3 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox2 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.btnPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.btnArchive = new Guna.UI2.WinForms.Guna2Button();
            this.btnSms = new Guna.UI2.WinForms.Guna2Button();
            this.btnWatching = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.pnlContent = new Guna.UI2.WinForms.Guna2Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.guna2DataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.login1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.adminDataSet = new viewminder1.AdminDataSet();
            this.guna2Button24 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button25 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button26 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TextBox8 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.guna2Button9 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel7 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel11 = new Guna.UI2.WinForms.Guna2Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.guna2Separator5 = new Guna.UI2.WinForms.Guna2Separator();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.guna2Separator4 = new Guna.UI2.WinForms.Guna2Separator();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.guna2Separator2 = new Guna.UI2.WinForms.Guna2Separator();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button10 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button11 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel8 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel12 = new Guna.UI2.WinForms.Guna2Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.guna2Separator7 = new Guna.UI2.WinForms.Guna2Separator();
            this.label22 = new System.Windows.Forms.Label();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.guna2Separator6 = new Guna.UI2.WinForms.Guna2Separator();
            this.label19 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.guna2Separator3 = new Guna.UI2.WinForms.Guna2Separator();
            this.label7 = new System.Windows.Forms.Label();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button12 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button13 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel9 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel13 = new Guna.UI2.WinForms.Guna2Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.guna2Separator8 = new Guna.UI2.WinForms.Guna2Separator();
            this.label27 = new System.Windows.Forms.Label();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.guna2Separator9 = new Guna.UI2.WinForms.Guna2Separator();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.guna2Separator10 = new Guna.UI2.WinForms.Guna2Separator();
            this.label33 = new System.Windows.Forms.Label();
            this.guna2HtmlLabel11 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.guna2Button14 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel12 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.guna2Button15 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TextBox7 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel16 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox6 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel17 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox4 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel19 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox3 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel20 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel21 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel22 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button16 = new Guna.UI2.WinForms.Guna2Button();
            this.label52 = new System.Windows.Forms.Label();
            this.guna2HtmlLabel15 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button17 = new Guna.UI2.WinForms.Guna2Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.guna2Button18 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TextBox9 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox10 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox12 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox13 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox14 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel13 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox15 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel14 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel23 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button19 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel24 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.guna2Button20 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TextBox16 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel25 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox17 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel26 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox19 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel28 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox20 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel29 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox21 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel30 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox22 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel31 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel32 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button21 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel33 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox7 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.login1TableAdapter = new viewminder1.AdminDataSetTableAdapters.login1TableAdapter();
            this.usernameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwordDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fullNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pinDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.guna2Panel2.SuspendLayout();
            this.btnPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.pnlContent.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.login1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.adminDataSet)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.guna2Panel7.SuspendLayout();
            this.guna2Panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.guna2Panel8.SuspendLayout();
            this.guna2Panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.guna2Panel9.SuspendLayout();
            this.guna2Panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.guna2Panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.BackColor = System.Drawing.Color.White;
            this.guna2Panel2.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Panel2.BorderRadius = 1;
            this.guna2Panel2.BorderThickness = 1;
            this.guna2Panel2.Controls.Add(this.guna2ControlBox3);
            this.guna2Panel2.Controls.Add(this.guna2ControlBox1);
            this.guna2Panel2.Controls.Add(this.guna2ControlBox2);
            this.guna2Panel2.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.guna2Panel2.CustomBorderThickness = new System.Windows.Forms.Padding(1, 0, 0, 0);
            this.guna2Panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel2.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            this.guna2Panel2.Size = new System.Drawing.Size(1473, 20);
            this.guna2Panel2.TabIndex = 2;
            // 
            // guna2ControlBox3
            // 
            this.guna2ControlBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox3.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.guna2ControlBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox3.HoverState.Parent = this.guna2ControlBox3;
            this.guna2ControlBox3.IconColor = System.Drawing.Color.Black;
            this.guna2ControlBox3.Location = new System.Drawing.Point(1374, 3);
            this.guna2ControlBox3.Name = "guna2ControlBox3";
            this.guna2ControlBox3.ShadowDecoration.Parent = this.guna2ControlBox3;
            this.guna2ControlBox3.Size = new System.Drawing.Size(25, 14);
            this.guna2ControlBox3.TabIndex = 7;
            // 
            // guna2ControlBox1
            // 
            this.guna2ControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox1.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MaximizeBox;
            this.guna2ControlBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.HoverState.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.IconColor = System.Drawing.Color.Black;
            this.guna2ControlBox1.Location = new System.Drawing.Point(1409, 3);
            this.guna2ControlBox1.Name = "guna2ControlBox1";
            this.guna2ControlBox1.ShadowDecoration.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.Size = new System.Drawing.Size(25, 14);
            this.guna2ControlBox1.TabIndex = 6;
            // 
            // guna2ControlBox2
            // 
            this.guna2ControlBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox2.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox2.HoverState.Parent = this.guna2ControlBox2;
            this.guna2ControlBox2.IconColor = System.Drawing.Color.Black;
            this.guna2ControlBox2.Location = new System.Drawing.Point(1441, 3);
            this.guna2ControlBox2.Name = "guna2ControlBox2";
            this.guna2ControlBox2.ShadowDecoration.Parent = this.guna2ControlBox2;
            this.guna2ControlBox2.Size = new System.Drawing.Size(25, 14);
            this.guna2ControlBox2.TabIndex = 5;
            // 
            // btnPanel
            // 
            this.btnPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.btnPanel.Controls.Add(this.guna2Button3);
            this.btnPanel.Controls.Add(this.guna2Button8);
            this.btnPanel.Controls.Add(this.guna2Button7);
            this.btnPanel.Controls.Add(this.guna2Button2);
            this.btnPanel.Controls.Add(this.btnArchive);
            this.btnPanel.Controls.Add(this.btnSms);
            this.btnPanel.Controls.Add(this.btnWatching);
            this.btnPanel.Controls.Add(this.guna2HtmlLabel2);
            this.btnPanel.Controls.Add(this.guna2PictureBox1);
            this.btnPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnPanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnPanel.Location = new System.Drawing.Point(0, 20);
            this.btnPanel.Name = "btnPanel";
            this.btnPanel.ShadowDecoration.Parent = this.btnPanel;
            this.btnPanel.Size = new System.Drawing.Size(274, 838);
            this.btnPanel.TabIndex = 4;
            // 
            // guna2Button3
            // 
            this.guna2Button3.BorderRadius = 9;
            this.guna2Button3.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button3.CheckedState.Parent = this.guna2Button3;
            this.guna2Button3.CustomImages.Parent = this.guna2Button3;
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button3.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button3.HoverState.Parent = this.guna2Button3;
            this.guna2Button3.Image = global::viewminder1.Properties.Resources.ic_baseline_logout;
            this.guna2Button3.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button3.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button3.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button3.Location = new System.Drawing.Point(23, 431);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.ShadowDecoration.Parent = this.guna2Button3;
            this.guna2Button3.Size = new System.Drawing.Size(226, 44);
            this.guna2Button3.TabIndex = 16;
            this.guna2Button3.Text = "Logout";
            this.guna2Button3.TextOffset = new System.Drawing.Point(-27, 0);
            this.guna2Button3.Click += new System.EventHandler(this.Guna2Button3_Click);
            // 
            // guna2Button8
            // 
            this.guna2Button8.BorderRadius = 9;
            this.guna2Button8.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button8.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button8.CheckedState.Parent = this.guna2Button8;
            this.guna2Button8.CustomImages.Parent = this.guna2Button8;
            this.guna2Button8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button8.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button8.ForeColor = System.Drawing.Color.White;
            this.guna2Button8.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button8.HoverState.Parent = this.guna2Button8;
            this.guna2Button8.Image = global::viewminder1.Properties.Resources.ic_baseline_logout;
            this.guna2Button8.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button8.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button8.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button8.Location = new System.Drawing.Point(23, 381);
            this.guna2Button8.Name = "guna2Button8";
            this.guna2Button8.ShadowDecoration.Parent = this.guna2Button8;
            this.guna2Button8.Size = new System.Drawing.Size(226, 44);
            this.guna2Button8.TabIndex = 15;
            this.guna2Button8.Text = "Login History";
            this.guna2Button8.TextOffset = new System.Drawing.Point(-5, 0);
            this.guna2Button8.Click += new System.EventHandler(this.Guna2Button8_Click);
            // 
            // guna2Button7
            // 
            this.guna2Button7.BorderRadius = 9;
            this.guna2Button7.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button7.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button7.CheckedState.Parent = this.guna2Button7;
            this.guna2Button7.CustomImages.Parent = this.guna2Button7;
            this.guna2Button7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button7.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button7.ForeColor = System.Drawing.Color.White;
            this.guna2Button7.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button7.HoverState.Parent = this.guna2Button7;
            this.guna2Button7.Image = global::viewminder1.Properties.Resources.ic_baseline_account_circle;
            this.guna2Button7.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button7.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button7.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button7.Location = new System.Drawing.Point(23, 331);
            this.guna2Button7.Name = "guna2Button7";
            this.guna2Button7.ShadowDecoration.Parent = this.guna2Button7;
            this.guna2Button7.Size = new System.Drawing.Size(226, 44);
            this.guna2Button7.TabIndex = 15;
            this.guna2Button7.Text = "Profile";
            this.guna2Button7.TextOffset = new System.Drawing.Point(-25, 0);
            this.guna2Button7.Click += new System.EventHandler(this.Guna2Button7_Click);
            // 
            // guna2Button2
            // 
            this.guna2Button2.BorderRadius = 9;
            this.guna2Button2.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button2.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Image = global::viewminder1.Properties.Resources.ic_baseline_notifications;
            this.guna2Button2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button2.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button2.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button2.Location = new System.Drawing.Point(23, 281);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Size = new System.Drawing.Size(226, 44);
            this.guna2Button2.TabIndex = 15;
            this.guna2Button2.Text = "Notification";
            this.guna2Button2.TextOffset = new System.Drawing.Point(-8, 0);
            this.guna2Button2.Click += new System.EventHandler(this.Guna2Button2_Click);
            // 
            // btnArchive
            // 
            this.btnArchive.BackColor = System.Drawing.Color.Transparent;
            this.btnArchive.BorderRadius = 9;
            this.btnArchive.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnArchive.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.btnArchive.CheckedState.ForeColor = System.Drawing.Color.White;
            this.btnArchive.CheckedState.Parent = this.btnArchive;
            this.btnArchive.CustomImages.Parent = this.btnArchive;
            this.btnArchive.FillColor = System.Drawing.Color.Transparent;
            this.btnArchive.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArchive.ForeColor = System.Drawing.Color.White;
            this.btnArchive.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.btnArchive.HoverState.Parent = this.btnArchive;
            this.btnArchive.Image = global::viewminder1.Properties.Resources.material_symbols_archive;
            this.btnArchive.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnArchive.ImageOffset = new System.Drawing.Point(16, 0);
            this.btnArchive.ImageSize = new System.Drawing.Size(16, 16);
            this.btnArchive.Location = new System.Drawing.Point(23, 231);
            this.btnArchive.Name = "btnArchive";
            this.btnArchive.ShadowDecoration.Parent = this.btnArchive;
            this.btnArchive.Size = new System.Drawing.Size(226, 44);
            this.btnArchive.TabIndex = 14;
            this.btnArchive.Text = "Archive";
            this.btnArchive.TextOffset = new System.Drawing.Point(-24, 0);
            this.btnArchive.Click += new System.EventHandler(this.BtnArchive_Click);
            // 
            // btnSms
            // 
            this.btnSms.BorderRadius = 9;
            this.btnSms.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnSms.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.btnSms.CheckedState.Parent = this.btnSms;
            this.btnSms.CustomImages.Parent = this.btnSms;
            this.btnSms.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.btnSms.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSms.ForeColor = System.Drawing.Color.White;
            this.btnSms.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.btnSms.HoverState.Parent = this.btnSms;
            this.btnSms.Image = global::viewminder1.Properties.Resources.material_symbols_sms_sharp;
            this.btnSms.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSms.ImageOffset = new System.Drawing.Point(16, 0);
            this.btnSms.ImageSize = new System.Drawing.Size(16, 16);
            this.btnSms.Location = new System.Drawing.Point(23, 181);
            this.btnSms.Name = "btnSms";
            this.btnSms.ShadowDecoration.Parent = this.btnSms;
            this.btnSms.Size = new System.Drawing.Size(226, 44);
            this.btnSms.TabIndex = 13;
            this.btnSms.Text = "Messages";
            this.btnSms.TextOffset = new System.Drawing.Point(-17, 0);
            this.btnSms.Click += new System.EventHandler(this.BtnSms_Click);
            // 
            // btnWatching
            // 
            this.btnWatching.BorderRadius = 9;
            this.btnWatching.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnWatching.Checked = true;
            this.btnWatching.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.btnWatching.CheckedState.Parent = this.btnWatching;
            this.btnWatching.CustomImages.Parent = this.btnWatching;
            this.btnWatching.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.btnWatching.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWatching.ForeColor = System.Drawing.Color.White;
            this.btnWatching.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.btnWatching.HoverState.Parent = this.btnWatching;
            this.btnWatching.Image = global::viewminder1.Properties.Resources.carbon_view_filled;
            this.btnWatching.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnWatching.ImageOffset = new System.Drawing.Point(16, 0);
            this.btnWatching.ImageSize = new System.Drawing.Size(16, 16);
            this.btnWatching.Location = new System.Drawing.Point(23, 131);
            this.btnWatching.Name = "btnWatching";
            this.btnWatching.ShadowDecoration.Parent = this.btnWatching;
            this.btnWatching.Size = new System.Drawing.Size(226, 44);
            this.btnWatching.TabIndex = 9;
            this.btnWatching.Text = "Manage Accounts";
            this.btnWatching.TextOffset = new System.Drawing.Point(10, 0);
            this.btnWatching.Click += new System.EventHandler(this.BtnWatching_Click);
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(23, 98);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(95, 21);
            this.guna2HtmlLabel2.TabIndex = 4;
            this.guna2HtmlLabel2.Text = "MAIN MENU";
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = global::viewminder1.Properties.Resources.logo2;
            this.guna2PictureBox1.Location = new System.Drawing.Point(23, 17);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(199, 64);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.guna2PictureBox1.TabIndex = 0;
            this.guna2PictureBox1.TabStop = false;
            // 
            // pnlContent
            // 
            this.pnlContent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(248)))));
            this.pnlContent.Controls.Add(this.flowLayoutPanel1);
            this.pnlContent.Controls.Add(this.tabControl1);
            this.pnlContent.Controls.Add(this.guna2Panel3);
            this.pnlContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContent.Location = new System.Drawing.Point(274, 20);
            this.pnlContent.Name = "pnlContent";
            this.pnlContent.ShadowDecoration.Parent = this.pnlContent;
            this.pnlContent.Size = new System.Drawing.Size(1199, 838);
            this.pnlContent.TabIndex = 7;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.Location = new System.Drawing.Point(587, 49);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(576, 26);
            this.flowLayoutPanel1.TabIndex = 20;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Location = new System.Drawing.Point(25, 49);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1142, 777);
            this.tabControl1.TabIndex = 19;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.TabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.guna2DataGridView1);
            this.tabPage1.Controls.Add(this.guna2Button24);
            this.tabPage1.Controls.Add(this.guna2Button25);
            this.tabPage1.Controls.Add(this.guna2Button26);
            this.tabPage1.Controls.Add(this.guna2TextBox8);
            this.tabPage1.Controls.Add(this.guna2HtmlLabel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1134, 751);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // guna2DataGridView1
            // 
            this.guna2DataGridView1.AllowUserToAddRows = false;
            this.guna2DataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.guna2DataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2DataGridView1.AutoGenerateColumns = false;
            this.guna2DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.guna2DataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.guna2DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.guna2DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.guna2DataGridView1.ColumnHeadersHeight = 21;
            this.guna2DataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.usernameDataGridViewTextBoxColumn1,
            this.passwordDataGridViewTextBoxColumn1,
            this.idDataGridViewTextBoxColumn1,
            this.fullNameDataGridViewTextBoxColumn1,
            this.emailDataGridViewTextBoxColumn1,
            this.pinDataGridViewTextBoxColumn1});
            this.guna2DataGridView1.DataSource = this.login1BindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.guna2DataGridView1.EnableHeadersVisualStyles = false;
            this.guna2DataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.Location = new System.Drawing.Point(28, 150);
            this.guna2DataGridView1.Name = "guna2DataGridView1";
            this.guna2DataGridView1.ReadOnly = true;
            this.guna2DataGridView1.RowHeadersVisible = false;
            this.guna2DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.guna2DataGridView1.Size = new System.Drawing.Size(1080, 571);
            this.guna2DataGridView1.TabIndex = 24;
            this.guna2DataGridView1.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Height = 21;
            this.guna2DataGridView1.ThemeStyle.ReadOnly = true;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.guna2DataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Height = 22;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Guna2DataGridView1_CellContentClick);
            // 
            // login1BindingSource
            // 
            this.login1BindingSource.DataMember = "login1";
            this.login1BindingSource.DataSource = this.adminDataSet;
            // 
            // adminDataSet
            // 
            this.adminDataSet.DataSetName = "AdminDataSet";
            this.adminDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // guna2Button24
            // 
            this.guna2Button24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button24.BackColor = System.Drawing.Color.White;
            this.guna2Button24.BorderRadius = 9;
            this.guna2Button24.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button24.CheckedState.Parent = this.guna2Button24;
            this.guna2Button24.CustomImages.Parent = this.guna2Button24;
            this.guna2Button24.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button24.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button24.ForeColor = System.Drawing.Color.White;
            this.guna2Button24.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button24.HoverState.Parent = this.guna2Button24;
            this.guna2Button24.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button24.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button24.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button24.Location = new System.Drawing.Point(693, 79);
            this.guna2Button24.Name = "guna2Button24";
            this.guna2Button24.ShadowDecoration.Parent = this.guna2Button24;
            this.guna2Button24.Size = new System.Drawing.Size(189, 34);
            this.guna2Button24.TabIndex = 22;
            this.guna2Button24.Text = "Create new admin";
            this.guna2Button24.Click += new System.EventHandler(this.Guna2Button24_Click);
            // 
            // guna2Button25
            // 
            this.guna2Button25.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button25.BackColor = System.Drawing.Color.White;
            this.guna2Button25.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button25.BorderRadius = 9;
            this.guna2Button25.BorderThickness = 1;
            this.guna2Button25.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button25.CheckedState.Parent = this.guna2Button25;
            this.guna2Button25.CustomImages.Parent = this.guna2Button25;
            this.guna2Button25.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button25.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(164)))), ((int)(((byte)(151)))));
            this.guna2Button25.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button25.HoverState.Parent = this.guna2Button25;
            this.guna2Button25.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button25.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button25.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button25.Location = new System.Drawing.Point(905, 79);
            this.guna2Button25.Name = "guna2Button25";
            this.guna2Button25.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button25.ShadowDecoration.Parent = this.guna2Button25;
            this.guna2Button25.Size = new System.Drawing.Size(95, 34);
            this.guna2Button25.TabIndex = 21;
            this.guna2Button25.Text = "Edit";
            this.guna2Button25.Click += new System.EventHandler(this.Guna2Button25_Click);
            // 
            // guna2Button26
            // 
            this.guna2Button26.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button26.BackColor = System.Drawing.Color.White;
            this.guna2Button26.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button26.BorderRadius = 9;
            this.guna2Button26.BorderThickness = 1;
            this.guna2Button26.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button26.CheckedState.Parent = this.guna2Button26;
            this.guna2Button26.CustomImages.Parent = this.guna2Button26;
            this.guna2Button26.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button26.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.guna2Button26.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button26.HoverState.Parent = this.guna2Button26;
            this.guna2Button26.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button26.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button26.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button26.Location = new System.Drawing.Point(1013, 79);
            this.guna2Button26.Name = "guna2Button26";
            this.guna2Button26.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button26.ShadowDecoration.Parent = this.guna2Button26;
            this.guna2Button26.Size = new System.Drawing.Size(95, 34);
            this.guna2Button26.TabIndex = 20;
            this.guna2Button26.Text = "Delete";
            this.guna2Button26.Click += new System.EventHandler(this.Guna2Button26_Click);
            // 
            // guna2TextBox8
            // 
            this.guna2TextBox8.BorderColor = System.Drawing.Color.SlateGray;
            this.guna2TextBox8.BorderRadius = 6;
            this.guna2TextBox8.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox8.DefaultText = "";
            this.guna2TextBox8.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox8.DisabledState.Parent = this.guna2TextBox8;
            this.guna2TextBox8.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox8.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox8.FocusedState.Parent = this.guna2TextBox8;
            this.guna2TextBox8.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox8.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox8.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox8.HoverState.Parent = this.guna2TextBox8;
            this.guna2TextBox8.IconRight = global::viewminder1.Properties.Resources.search;
            this.guna2TextBox8.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox8.Location = new System.Drawing.Point(28, 79);
            this.guna2TextBox8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox8.Name = "guna2TextBox8";
            this.guna2TextBox8.PasswordChar = '\0';
            this.guna2TextBox8.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox8.PlaceholderText = "Search";
            this.guna2TextBox8.SelectedText = "";
            this.guna2TextBox8.ShadowDecoration.Parent = this.guna2TextBox8;
            this.guna2TextBox8.Size = new System.Drawing.Size(247, 34);
            this.guna2TextBox8.TabIndex = 18;
            this.guna2TextBox8.TextChanged += new System.EventHandler(this.Guna2TextBox8_TextChanged);
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(28, 31);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(184, 27);
            this.guna2HtmlLabel1.TabIndex = 14;
            this.guna2HtmlLabel1.Text = "Manage Accounts";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.guna2Button9);
            this.tabPage2.Controls.Add(this.guna2Button6);
            this.tabPage2.Controls.Add(this.guna2Panel7);
            this.tabPage2.Controls.Add(this.guna2Button5);
            this.tabPage2.Controls.Add(this.guna2HtmlLabel6);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1134, 751);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // guna2Button9
            // 
            this.guna2Button9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button9.BackColor = System.Drawing.Color.White;
            this.guna2Button9.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button9.BorderRadius = 9;
            this.guna2Button9.BorderThickness = 1;
            this.guna2Button9.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button9.CheckedState.Parent = this.guna2Button9;
            this.guna2Button9.CustomImages.Parent = this.guna2Button9;
            this.guna2Button9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button9.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button9.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button9.HoverState.Parent = this.guna2Button9;
            this.guna2Button9.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button9.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button9.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button9.Location = new System.Drawing.Point(985, 40);
            this.guna2Button9.Name = "guna2Button9";
            this.guna2Button9.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button9.ShadowDecoration.Parent = this.guna2Button9;
            this.guna2Button9.Size = new System.Drawing.Size(95, 34);
            this.guna2Button9.TabIndex = 19;
            this.guna2Button9.Text = "Select all";
            // 
            // guna2Button6
            // 
            this.guna2Button6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button6.BackColor = System.Drawing.Color.White;
            this.guna2Button6.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button6.BorderRadius = 9;
            this.guna2Button6.BorderThickness = 1;
            this.guna2Button6.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button6.CheckedState.Parent = this.guna2Button6;
            this.guna2Button6.CustomImages.Parent = this.guna2Button6;
            this.guna2Button6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button6.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button6.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button6.HoverState.Parent = this.guna2Button6;
            this.guna2Button6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button6.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button6.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button6.Location = new System.Drawing.Point(883, 40);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button6.ShadowDecoration.Parent = this.guna2Button6;
            this.guna2Button6.Size = new System.Drawing.Size(95, 34);
            this.guna2Button6.TabIndex = 18;
            this.guna2Button6.Text = "Cancel";
            // 
            // guna2Panel7
            // 
            this.guna2Panel7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel7.BackColor = System.Drawing.Color.White;
            this.guna2Panel7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(209)))), ((int)(((byte)(213)))));
            this.guna2Panel7.BorderRadius = 6;
            this.guna2Panel7.BorderThickness = 1;
            this.guna2Panel7.Controls.Add(this.guna2Panel11);
            this.guna2Panel7.Controls.Add(this.pictureBox15);
            this.guna2Panel7.Controls.Add(this.label12);
            this.guna2Panel7.Controls.Add(this.pictureBox16);
            this.guna2Panel7.Controls.Add(this.guna2Separator5);
            this.guna2Panel7.Controls.Add(this.label13);
            this.guna2Panel7.Controls.Add(this.label14);
            this.guna2Panel7.Controls.Add(this.pictureBox14);
            this.guna2Panel7.Controls.Add(this.label9);
            this.guna2Panel7.Controls.Add(this.pictureBox13);
            this.guna2Panel7.Controls.Add(this.guna2Separator4);
            this.guna2Panel7.Controls.Add(this.label10);
            this.guna2Panel7.Controls.Add(this.label11);
            this.guna2Panel7.Controls.Add(this.label5);
            this.guna2Panel7.Controls.Add(this.pictureBox11);
            this.guna2Panel7.Controls.Add(this.guna2Separator2);
            this.guna2Panel7.Controls.Add(this.label3);
            this.guna2Panel7.Controls.Add(this.label4);
            this.guna2Panel7.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(209)))), ((int)(((byte)(213)))));
            this.guna2Panel7.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel7.Location = new System.Drawing.Point(28, 90);
            this.guna2Panel7.Name = "guna2Panel7";
            this.guna2Panel7.ShadowDecoration.Parent = this.guna2Panel7;
            this.guna2Panel7.Size = new System.Drawing.Size(1052, 590);
            this.guna2Panel7.TabIndex = 17;
            // 
            // guna2Panel11
            // 
            this.guna2Panel11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(255)))), ((int)(((byte)(216)))));
            this.guna2Panel11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(197)))), ((int)(((byte)(153)))));
            this.guna2Panel11.BorderRadius = 15;
            this.guna2Panel11.BorderThickness = 1;
            this.guna2Panel11.Controls.Add(this.label16);
            this.guna2Panel11.Controls.Add(this.label15);
            this.guna2Panel11.Controls.Add(this.pictureBox17);
            this.guna2Panel11.Location = new System.Drawing.Point(604, 458);
            this.guna2Panel11.Name = "guna2Panel11";
            this.guna2Panel11.ShadowDecoration.Parent = this.guna2Panel11;
            this.guna2Panel11.Size = new System.Drawing.Size(415, 90);
            this.guna2Panel11.TabIndex = 21;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(149)))), ((int)(((byte)(14)))));
            this.label16.Location = new System.Drawing.Point(22, 52);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(327, 19);
            this.label16.TabIndex = 17;
            this.label16.Text = "The changes has been saved to the database.";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(149)))), ((int)(((byte)(14)))));
            this.label15.Location = new System.Drawing.Point(22, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(326, 19);
            this.label15.TabIndex = 10;
            this.label15.Text = "Messages has been removed successfully.";
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::viewminder1.Properties.Resources.Vector;
            this.pictureBox17.Location = new System.Drawing.Point(374, 12);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(28, 28);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox17.TabIndex = 8;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::viewminder1.Properties.Resources.carbon_checkbox;
            this.pictureBox15.Location = new System.Drawing.Point(17, 98);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(28, 28);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox15.TabIndex = 20;
            this.pictureBox15.TabStop = false;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label12.Location = new System.Drawing.Point(972, 102);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 19);
            this.label12.TabIndex = 19;
            this.label12.Text = "5:14 PM";
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::viewminder1.Properties.Resources.ic_round_warning;
            this.pictureBox16.Location = new System.Drawing.Point(57, 98);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(28, 28);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox16.TabIndex = 18;
            this.pictureBox16.TabStop = false;
            // 
            // guna2Separator5
            // 
            this.guna2Separator5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator5.Location = new System.Drawing.Point(3, 129);
            this.guna2Separator5.Name = "guna2Separator5";
            this.guna2Separator5.Size = new System.Drawing.Size(1046, 10);
            this.guna2Separator5.TabIndex = 17;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(228, 102);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(426, 19);
            this.label13.TabIndex = 16;
            this.label13.Text = "- Cam 1 | Room 3 : Motion detected at 2023-08-14 | 5: 14 PM ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(91, 102);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(142, 19);
            this.label14.TabIndex = 15;
            this.label14.Text = "Motion detection ";
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::viewminder1.Properties.Resources.ion_checkbox;
            this.pictureBox14.Location = new System.Drawing.Point(17, 54);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(28, 28);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox14.TabIndex = 14;
            this.pictureBox14.TabStop = false;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label9.Location = new System.Drawing.Point(972, 58);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 19);
            this.label9.TabIndex = 13;
            this.label9.Text = "5:14 PM";
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::viewminder1.Properties.Resources.ic_round_warning;
            this.pictureBox13.Location = new System.Drawing.Point(57, 54);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(28, 28);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox13.TabIndex = 12;
            this.pictureBox13.TabStop = false;
            // 
            // guna2Separator4
            // 
            this.guna2Separator4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator4.Location = new System.Drawing.Point(3, 85);
            this.guna2Separator4.Name = "guna2Separator4";
            this.guna2Separator4.Size = new System.Drawing.Size(1046, 10);
            this.guna2Separator4.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(228, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(426, 19);
            this.label10.TabIndex = 10;
            this.label10.Text = "- Cam 1 | Room 3 : Motion detected at 2023-08-14 | 5: 14 PM ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(91, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(142, 19);
            this.label11.TabIndex = 9;
            this.label11.Text = "Motion detection ";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label5.Location = new System.Drawing.Point(972, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 19);
            this.label5.TabIndex = 8;
            this.label5.Text = "5:14 PM";
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::viewminder1.Properties.Resources.ic_round_warning;
            this.pictureBox11.Location = new System.Drawing.Point(17, 8);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(28, 28);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox11.TabIndex = 7;
            this.pictureBox11.TabStop = false;
            // 
            // guna2Separator2
            // 
            this.guna2Separator2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator2.Location = new System.Drawing.Point(3, 39);
            this.guna2Separator2.Name = "guna2Separator2";
            this.guna2Separator2.Size = new System.Drawing.Size(1046, 10);
            this.guna2Separator2.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(188, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(426, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "- Cam 1 | Room 3 : Motion detected at 2023-08-14 | 5: 14 PM ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(51, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "Motion detection ";
            // 
            // guna2Button5
            // 
            this.guna2Button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button5.BackColor = System.Drawing.Color.White;
            this.guna2Button5.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button5.BorderRadius = 9;
            this.guna2Button5.BorderThickness = 1;
            this.guna2Button5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button5.CheckedState.Parent = this.guna2Button5;
            this.guna2Button5.CustomImages.Parent = this.guna2Button5;
            this.guna2Button5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button5.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.guna2Button5.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button5.HoverState.Parent = this.guna2Button5;
            this.guna2Button5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button5.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button5.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button5.Location = new System.Drawing.Point(782, 40);
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button5.ShadowDecoration.Parent = this.guna2Button5;
            this.guna2Button5.Size = new System.Drawing.Size(95, 34);
            this.guna2Button5.TabIndex = 16;
            this.guna2Button5.Text = "Delete";
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(28, 31);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(102, 27);
            this.guna2HtmlLabel6.TabIndex = 13;
            this.guna2HtmlLabel6.Text = "Messages";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.guna2Button1);
            this.tabPage3.Controls.Add(this.guna2Button10);
            this.tabPage3.Controls.Add(this.guna2Button11);
            this.tabPage3.Controls.Add(this.guna2Panel8);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel7);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1134, 751);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // guna2Button1
            // 
            this.guna2Button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button1.BackColor = System.Drawing.Color.White;
            this.guna2Button1.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button1.BorderRadius = 9;
            this.guna2Button1.BorderThickness = 1;
            this.guna2Button1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button1.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button1.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button1.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button1.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button1.Location = new System.Drawing.Point(985, 40);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(95, 34);
            this.guna2Button1.TabIndex = 22;
            this.guna2Button1.Text = "Select all";
            // 
            // guna2Button10
            // 
            this.guna2Button10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button10.BackColor = System.Drawing.Color.White;
            this.guna2Button10.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button10.BorderRadius = 9;
            this.guna2Button10.BorderThickness = 1;
            this.guna2Button10.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button10.CheckedState.Parent = this.guna2Button10;
            this.guna2Button10.CustomImages.Parent = this.guna2Button10;
            this.guna2Button10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button10.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button10.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button10.HoverState.Parent = this.guna2Button10;
            this.guna2Button10.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button10.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button10.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button10.Location = new System.Drawing.Point(883, 40);
            this.guna2Button10.Name = "guna2Button10";
            this.guna2Button10.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button10.ShadowDecoration.Parent = this.guna2Button10;
            this.guna2Button10.Size = new System.Drawing.Size(95, 34);
            this.guna2Button10.TabIndex = 21;
            this.guna2Button10.Text = "Cancel";
            // 
            // guna2Button11
            // 
            this.guna2Button11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button11.BackColor = System.Drawing.Color.White;
            this.guna2Button11.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button11.BorderRadius = 9;
            this.guna2Button11.BorderThickness = 1;
            this.guna2Button11.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button11.CheckedState.Parent = this.guna2Button11;
            this.guna2Button11.CustomImages.Parent = this.guna2Button11;
            this.guna2Button11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button11.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.guna2Button11.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button11.HoverState.Parent = this.guna2Button11;
            this.guna2Button11.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button11.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button11.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button11.Location = new System.Drawing.Point(782, 40);
            this.guna2Button11.Name = "guna2Button11";
            this.guna2Button11.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button11.ShadowDecoration.Parent = this.guna2Button11;
            this.guna2Button11.Size = new System.Drawing.Size(95, 34);
            this.guna2Button11.TabIndex = 20;
            this.guna2Button11.Text = "Delete";
            // 
            // guna2Panel8
            // 
            this.guna2Panel8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel8.BackColor = System.Drawing.Color.White;
            this.guna2Panel8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(209)))), ((int)(((byte)(213)))));
            this.guna2Panel8.BorderRadius = 6;
            this.guna2Panel8.BorderThickness = 1;
            this.guna2Panel8.Controls.Add(this.guna2Panel12);
            this.guna2Panel8.Controls.Add(this.pictureBox20);
            this.guna2Panel8.Controls.Add(this.label20);
            this.guna2Panel8.Controls.Add(this.label21);
            this.guna2Panel8.Controls.Add(this.pictureBox21);
            this.guna2Panel8.Controls.Add(this.guna2Separator7);
            this.guna2Panel8.Controls.Add(this.label22);
            this.guna2Panel8.Controls.Add(this.pictureBox19);
            this.guna2Panel8.Controls.Add(this.label17);
            this.guna2Panel8.Controls.Add(this.label18);
            this.guna2Panel8.Controls.Add(this.pictureBox18);
            this.guna2Panel8.Controls.Add(this.guna2Separator6);
            this.guna2Panel8.Controls.Add(this.label19);
            this.guna2Panel8.Controls.Add(this.label6);
            this.guna2Panel8.Controls.Add(this.label8);
            this.guna2Panel8.Controls.Add(this.pictureBox12);
            this.guna2Panel8.Controls.Add(this.guna2Separator3);
            this.guna2Panel8.Controls.Add(this.label7);
            this.guna2Panel8.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(209)))), ((int)(((byte)(213)))));
            this.guna2Panel8.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel8.Location = new System.Drawing.Point(28, 90);
            this.guna2Panel8.Name = "guna2Panel8";
            this.guna2Panel8.ShadowDecoration.Parent = this.guna2Panel8;
            this.guna2Panel8.Size = new System.Drawing.Size(1052, 590);
            this.guna2Panel8.TabIndex = 18;
            // 
            // guna2Panel12
            // 
            this.guna2Panel12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(255)))), ((int)(((byte)(216)))));
            this.guna2Panel12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(197)))), ((int)(((byte)(153)))));
            this.guna2Panel12.BorderRadius = 15;
            this.guna2Panel12.BorderThickness = 1;
            this.guna2Panel12.Controls.Add(this.label23);
            this.guna2Panel12.Controls.Add(this.label24);
            this.guna2Panel12.Controls.Add(this.pictureBox22);
            this.guna2Panel12.Location = new System.Drawing.Point(604, 458);
            this.guna2Panel12.Name = "guna2Panel12";
            this.guna2Panel12.ShadowDecoration.Parent = this.guna2Panel12;
            this.guna2Panel12.Size = new System.Drawing.Size(415, 90);
            this.guna2Panel12.TabIndex = 26;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(149)))), ((int)(((byte)(14)))));
            this.label23.Location = new System.Drawing.Point(22, 52);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(327, 19);
            this.label23.TabIndex = 17;
            this.label23.Text = "The changes has been saved to the database.";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(149)))), ((int)(((byte)(14)))));
            this.label24.Location = new System.Drawing.Point(22, 21);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(295, 19);
            this.label24.TabIndex = 10;
            this.label24.Text = "Video has been removed successfully.";
            // 
            // pictureBox22
            // 
            this.pictureBox22.Image = global::viewminder1.Properties.Resources.Vector;
            this.pictureBox22.Location = new System.Drawing.Point(374, 12);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(28, 28);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox22.TabIndex = 8;
            this.pictureBox22.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = global::viewminder1.Properties.Resources.carbon_checkbox;
            this.pictureBox20.Location = new System.Drawing.Point(17, 92);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(28, 28);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox20.TabIndex = 25;
            this.pictureBox20.TabStop = false;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label20.Location = new System.Drawing.Point(492, 96);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(120, 19);
            this.label20.TabIndex = 24;
            this.label20.Text = "August 20,2023";
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label21.Location = new System.Drawing.Point(972, 96);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(67, 19);
            this.label21.TabIndex = 23;
            this.label21.Text = "5:14 PM";
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = global::viewminder1.Properties.Resources.mdi_folder_play;
            this.pictureBox21.Location = new System.Drawing.Point(60, 92);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(28, 28);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox21.TabIndex = 22;
            this.pictureBox21.TabStop = false;
            // 
            // guna2Separator7
            // 
            this.guna2Separator7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator7.Location = new System.Drawing.Point(3, 123);
            this.guna2Separator7.Name = "guna2Separator7";
            this.guna2Separator7.Size = new System.Drawing.Size(1046, 10);
            this.guna2Separator7.TabIndex = 21;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(94, 96);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(200, 19);
            this.label22.TabIndex = 20;
            this.label22.Text = " Recorded video 12345678";
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = global::viewminder1.Properties.Resources.ion_checkbox;
            this.pictureBox19.Location = new System.Drawing.Point(17, 50);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(28, 28);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox19.TabIndex = 19;
            this.pictureBox19.TabStop = false;
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label17.Location = new System.Drawing.Point(492, 54);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(120, 19);
            this.label17.TabIndex = 18;
            this.label17.Text = "August 20,2023";
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label18.Location = new System.Drawing.Point(972, 54);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 19);
            this.label18.TabIndex = 17;
            this.label18.Text = "5:14 PM";
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::viewminder1.Properties.Resources.mdi_folder_play;
            this.pictureBox18.Location = new System.Drawing.Point(60, 50);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(28, 28);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox18.TabIndex = 16;
            this.pictureBox18.TabStop = false;
            // 
            // guna2Separator6
            // 
            this.guna2Separator6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator6.Location = new System.Drawing.Point(3, 81);
            this.guna2Separator6.Name = "guna2Separator6";
            this.guna2Separator6.Size = new System.Drawing.Size(1046, 10);
            this.guna2Separator6.TabIndex = 15;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(94, 54);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(200, 19);
            this.label19.TabIndex = 14;
            this.label19.Text = " Recorded video 12345678";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label6.Location = new System.Drawing.Point(449, 12);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 19);
            this.label6.TabIndex = 13;
            this.label6.Text = "August 20,2023";
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label8.Location = new System.Drawing.Point(972, 12);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 19);
            this.label8.TabIndex = 12;
            this.label8.Text = "5:14 PM";
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::viewminder1.Properties.Resources.mdi_folder_play;
            this.pictureBox12.Location = new System.Drawing.Point(17, 8);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(28, 28);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox12.TabIndex = 11;
            this.pictureBox12.TabStop = false;
            // 
            // guna2Separator3
            // 
            this.guna2Separator3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator3.Location = new System.Drawing.Point(3, 39);
            this.guna2Separator3.Name = "guna2Separator3";
            this.guna2Separator3.Size = new System.Drawing.Size(1046, 10);
            this.guna2Separator3.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(51, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(200, 19);
            this.label7.TabIndex = 8;
            this.label7.Text = " Recorded video 12345678";
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(28, 31);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(80, 27);
            this.guna2HtmlLabel7.TabIndex = 13;
            this.guna2HtmlLabel7.Text = "Archive";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.guna2Button4);
            this.tabPage4.Controls.Add(this.guna2Button12);
            this.tabPage4.Controls.Add(this.guna2Button13);
            this.tabPage4.Controls.Add(this.guna2Panel9);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel11);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1134, 751);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // guna2Button4
            // 
            this.guna2Button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button4.BackColor = System.Drawing.Color.White;
            this.guna2Button4.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button4.BorderRadius = 9;
            this.guna2Button4.BorderThickness = 1;
            this.guna2Button4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button4.CheckedState.Parent = this.guna2Button4;
            this.guna2Button4.CustomImages.Parent = this.guna2Button4;
            this.guna2Button4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button4.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button4.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button4.HoverState.Parent = this.guna2Button4;
            this.guna2Button4.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button4.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button4.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button4.Location = new System.Drawing.Point(985, 40);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button4.ShadowDecoration.Parent = this.guna2Button4;
            this.guna2Button4.Size = new System.Drawing.Size(95, 34);
            this.guna2Button4.TabIndex = 25;
            this.guna2Button4.Text = "Select all";
            // 
            // guna2Button12
            // 
            this.guna2Button12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button12.BackColor = System.Drawing.Color.White;
            this.guna2Button12.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button12.BorderRadius = 9;
            this.guna2Button12.BorderThickness = 1;
            this.guna2Button12.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button12.CheckedState.Parent = this.guna2Button12;
            this.guna2Button12.CustomImages.Parent = this.guna2Button12;
            this.guna2Button12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button12.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button12.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button12.HoverState.Parent = this.guna2Button12;
            this.guna2Button12.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button12.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button12.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button12.Location = new System.Drawing.Point(883, 40);
            this.guna2Button12.Name = "guna2Button12";
            this.guna2Button12.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button12.ShadowDecoration.Parent = this.guna2Button12;
            this.guna2Button12.Size = new System.Drawing.Size(95, 34);
            this.guna2Button12.TabIndex = 24;
            this.guna2Button12.Text = "Cancel";
            // 
            // guna2Button13
            // 
            this.guna2Button13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button13.BackColor = System.Drawing.Color.White;
            this.guna2Button13.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button13.BorderRadius = 9;
            this.guna2Button13.BorderThickness = 1;
            this.guna2Button13.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button13.CheckedState.Parent = this.guna2Button13;
            this.guna2Button13.CustomImages.Parent = this.guna2Button13;
            this.guna2Button13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button13.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.guna2Button13.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button13.HoverState.Parent = this.guna2Button13;
            this.guna2Button13.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button13.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button13.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button13.Location = new System.Drawing.Point(782, 40);
            this.guna2Button13.Name = "guna2Button13";
            this.guna2Button13.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button13.ShadowDecoration.Parent = this.guna2Button13;
            this.guna2Button13.Size = new System.Drawing.Size(95, 34);
            this.guna2Button13.TabIndex = 23;
            this.guna2Button13.Text = "Delete";
            // 
            // guna2Panel9
            // 
            this.guna2Panel9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel9.BackColor = System.Drawing.Color.White;
            this.guna2Panel9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(209)))), ((int)(((byte)(213)))));
            this.guna2Panel9.BorderRadius = 6;
            this.guna2Panel9.BorderThickness = 1;
            this.guna2Panel9.Controls.Add(this.guna2Panel13);
            this.guna2Panel9.Controls.Add(this.label34);
            this.guna2Panel9.Controls.Add(this.label2);
            this.guna2Panel9.Controls.Add(this.label1);
            this.guna2Panel9.Controls.Add(this.pictureBox23);
            this.guna2Panel9.Controls.Add(this.label25);
            this.guna2Panel9.Controls.Add(this.label26);
            this.guna2Panel9.Controls.Add(this.pictureBox24);
            this.guna2Panel9.Controls.Add(this.guna2Separator8);
            this.guna2Panel9.Controls.Add(this.label27);
            this.guna2Panel9.Controls.Add(this.pictureBox25);
            this.guna2Panel9.Controls.Add(this.label28);
            this.guna2Panel9.Controls.Add(this.label29);
            this.guna2Panel9.Controls.Add(this.pictureBox26);
            this.guna2Panel9.Controls.Add(this.guna2Separator9);
            this.guna2Panel9.Controls.Add(this.label30);
            this.guna2Panel9.Controls.Add(this.label31);
            this.guna2Panel9.Controls.Add(this.label32);
            this.guna2Panel9.Controls.Add(this.pictureBox27);
            this.guna2Panel9.Controls.Add(this.guna2Separator10);
            this.guna2Panel9.Controls.Add(this.label33);
            this.guna2Panel9.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(209)))), ((int)(((byte)(213)))));
            this.guna2Panel9.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel9.Location = new System.Drawing.Point(28, 90);
            this.guna2Panel9.Name = "guna2Panel9";
            this.guna2Panel9.ShadowDecoration.Parent = this.guna2Panel9;
            this.guna2Panel9.Size = new System.Drawing.Size(1052, 590);
            this.guna2Panel9.TabIndex = 19;
            // 
            // guna2Panel13
            // 
            this.guna2Panel13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(255)))), ((int)(((byte)(216)))));
            this.guna2Panel13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(197)))), ((int)(((byte)(153)))));
            this.guna2Panel13.BorderRadius = 15;
            this.guna2Panel13.BorderThickness = 1;
            this.guna2Panel13.Controls.Add(this.label35);
            this.guna2Panel13.Controls.Add(this.label36);
            this.guna2Panel13.Controls.Add(this.pictureBox2);
            this.guna2Panel13.Location = new System.Drawing.Point(604, 458);
            this.guna2Panel13.Name = "guna2Panel13";
            this.guna2Panel13.ShadowDecoration.Parent = this.guna2Panel13;
            this.guna2Panel13.Size = new System.Drawing.Size(415, 90);
            this.guna2Panel13.TabIndex = 46;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(149)))), ((int)(((byte)(14)))));
            this.label35.Location = new System.Drawing.Point(22, 52);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(327, 19);
            this.label35.TabIndex = 17;
            this.label35.Text = "The changes has been saved to the database.";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(149)))), ((int)(((byte)(14)))));
            this.label36.Location = new System.Drawing.Point(22, 21);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(341, 19);
            this.label36.TabIndex = 10;
            this.label36.Text = "Notification has been removed successfully.";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::viewminder1.Properties.Resources.Vector;
            this.pictureBox2.Location = new System.Drawing.Point(374, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(28, 28);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // label34
            // 
            this.label34.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(187, 95);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(429, 19);
            this.label34.TabIndex = 45;
            this.label34.Text = " - Cam 1 | Room 3 : Motion detected at 2023-08-14 | 5: 14 PM ";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(187, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(429, 19);
            this.label2.TabIndex = 44;
            this.label2.Text = " - Cam 1 | Room 3 : Motion detected at 2023-08-14 | 5: 14 PM ";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(160, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(416, 19);
            this.label1.TabIndex = 43;
            this.label1.Text = "- New user login  : Login detected at 2023-08-14 | 5: 14 PM ";
            // 
            // pictureBox23
            // 
            this.pictureBox23.Image = global::viewminder1.Properties.Resources.carbon_checkbox;
            this.pictureBox23.Location = new System.Drawing.Point(17, 91);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(28, 28);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox23.TabIndex = 42;
            this.pictureBox23.TabStop = false;
            // 
            // label25
            // 
            this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label25.Location = new System.Drawing.Point(750, 93);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(120, 19);
            this.label25.TabIndex = 41;
            this.label25.Text = "August 20,2023";
            // 
            // label26
            // 
            this.label26.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label26.Location = new System.Drawing.Point(972, 95);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(67, 19);
            this.label26.TabIndex = 40;
            this.label26.Text = "5:14 PM";
            // 
            // pictureBox24
            // 
            this.pictureBox24.Image = global::viewminder1.Properties.Resources.ic_round_warning;
            this.pictureBox24.Location = new System.Drawing.Point(60, 91);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(28, 28);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox24.TabIndex = 39;
            this.pictureBox24.TabStop = false;
            // 
            // guna2Separator8
            // 
            this.guna2Separator8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator8.Location = new System.Drawing.Point(3, 122);
            this.guna2Separator8.Name = "guna2Separator8";
            this.guna2Separator8.Size = new System.Drawing.Size(1046, 10);
            this.guna2Separator8.TabIndex = 38;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(94, 95);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(136, 19);
            this.label27.TabIndex = 37;
            this.label27.Text = "Motion detection";
            // 
            // pictureBox25
            // 
            this.pictureBox25.Image = global::viewminder1.Properties.Resources.ion_checkbox;
            this.pictureBox25.Location = new System.Drawing.Point(17, 49);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(28, 28);
            this.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox25.TabIndex = 36;
            this.pictureBox25.TabStop = false;
            // 
            // label28
            // 
            this.label28.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label28.Location = new System.Drawing.Point(750, 53);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(120, 19);
            this.label28.TabIndex = 35;
            this.label28.Text = "August 20,2023";
            // 
            // label29
            // 
            this.label29.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label29.Location = new System.Drawing.Point(972, 53);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(67, 19);
            this.label29.TabIndex = 34;
            this.label29.Text = "5:14 PM";
            // 
            // pictureBox26
            // 
            this.pictureBox26.Image = global::viewminder1.Properties.Resources.ic_round_warning;
            this.pictureBox26.Location = new System.Drawing.Point(60, 49);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(28, 28);
            this.pictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox26.TabIndex = 33;
            this.pictureBox26.TabStop = false;
            // 
            // guna2Separator9
            // 
            this.guna2Separator9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator9.Location = new System.Drawing.Point(3, 80);
            this.guna2Separator9.Name = "guna2Separator9";
            this.guna2Separator9.Size = new System.Drawing.Size(1046, 10);
            this.guna2Separator9.TabIndex = 32;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(94, 53);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(136, 19);
            this.label30.TabIndex = 31;
            this.label30.Text = "Motion detection";
            // 
            // label31
            // 
            this.label31.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label31.Location = new System.Drawing.Point(699, 11);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(120, 19);
            this.label31.TabIndex = 30;
            this.label31.Text = "August 20,2023";
            // 
            // label32
            // 
            this.label32.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label32.Location = new System.Drawing.Point(972, 11);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(67, 19);
            this.label32.TabIndex = 29;
            this.label32.Text = "5:14 PM";
            // 
            // pictureBox27
            // 
            this.pictureBox27.Image = global::viewminder1.Properties.Resources.clarity_login_solid;
            this.pictureBox27.Location = new System.Drawing.Point(17, 7);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(28, 28);
            this.pictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox27.TabIndex = 28;
            this.pictureBox27.TabStop = false;
            // 
            // guna2Separator10
            // 
            this.guna2Separator10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator10.Location = new System.Drawing.Point(3, 38);
            this.guna2Separator10.Name = "guna2Separator10";
            this.guna2Separator10.Size = new System.Drawing.Size(1046, 10);
            this.guna2Separator10.TabIndex = 27;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(51, 11);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(153, 19);
            this.label33.TabIndex = 26;
            this.label33.Text = "New login detected";
            // 
            // guna2HtmlLabel11
            // 
            this.guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel11.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel11.Location = new System.Drawing.Point(28, 31);
            this.guna2HtmlLabel11.Name = "guna2HtmlLabel11";
            this.guna2HtmlLabel11.Size = new System.Drawing.Size(123, 27);
            this.guna2HtmlLabel11.TabIndex = 14;
            this.guna2HtmlLabel11.Text = "Notification";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label50);
            this.tabPage5.Controls.Add(this.label51);
            this.tabPage5.Controls.Add(this.label48);
            this.tabPage5.Controls.Add(this.label49);
            this.tabPage5.Controls.Add(this.label46);
            this.tabPage5.Controls.Add(this.label47);
            this.tabPage5.Controls.Add(this.label42);
            this.tabPage5.Controls.Add(this.label43);
            this.tabPage5.Controls.Add(this.label40);
            this.tabPage5.Controls.Add(this.label41);
            this.tabPage5.Controls.Add(this.label39);
            this.tabPage5.Controls.Add(this.label38);
            this.tabPage5.Controls.Add(this.label37);
            this.tabPage5.Controls.Add(this.guna2Button14);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel12);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1134, 751);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(231, 342);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(114, 19);
            this.label50.TabIndex = 41;
            this.label50.Text = "Ilovepizza123";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(24, 342);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(87, 19);
            this.label51.TabIndex = 40;
            this.label51.Text = "Password:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(231, 295);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(49, 19);
            this.label48.TabIndex = 39;
            this.label48.Text = "1234";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(24, 295);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(37, 19);
            this.label49.TabIndex = 38;
            this.label49.Text = "Pin:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(231, 250);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(69, 19);
            this.label46.TabIndex = 37;
            this.label46.Text = "123487";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(24, 250);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(96, 19);
            this.label47.TabIndex = 36;
            this.label47.Text = "Account Id:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(231, 206);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(250, 19);
            this.label42.TabIndex = 33;
            this.label42.Text = "stevencabugos138@gmail.com ";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(24, 206);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(120, 19);
            this.label43.TabIndex = 32;
            this.label43.Text = "Email Address:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(231, 165);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(61, 19);
            this.label40.TabIndex = 31;
            this.label40.Text = "Steven";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(24, 165);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(93, 19);
            this.label41.TabIndex = 30;
            this.label41.Text = "Username: ";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(231, 124);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(132, 19);
            this.label39.TabIndex = 29;
            this.label39.Text = "Steven Cabugos";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(24, 124);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(91, 19);
            this.label38.TabIndex = 28;
            this.label38.Text = "Full Name: ";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Aileron Heavy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(24, 77);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(115, 19);
            this.label37.TabIndex = 27;
            this.label37.Text = "Profile Details";
            // 
            // guna2Button14
            // 
            this.guna2Button14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button14.BackColor = System.Drawing.Color.White;
            this.guna2Button14.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button14.BorderRadius = 9;
            this.guna2Button14.BorderThickness = 1;
            this.guna2Button14.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button14.CheckedState.Parent = this.guna2Button14;
            this.guna2Button14.CustomImages.Parent = this.guna2Button14;
            this.guna2Button14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button14.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button14.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button14.HoverState.Parent = this.guna2Button14;
            this.guna2Button14.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button14.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button14.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button14.Location = new System.Drawing.Point(946, 40);
            this.guna2Button14.Name = "guna2Button14";
            this.guna2Button14.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button14.ShadowDecoration.Parent = this.guna2Button14;
            this.guna2Button14.Size = new System.Drawing.Size(134, 34);
            this.guna2Button14.TabIndex = 25;
            this.guna2Button14.Text = "Edit Account";
            // 
            // guna2HtmlLabel12
            // 
            this.guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel12.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel12.Location = new System.Drawing.Point(28, 31);
            this.guna2HtmlLabel12.Name = "guna2HtmlLabel12";
            this.guna2HtmlLabel12.Size = new System.Drawing.Size(187, 27);
            this.guna2HtmlLabel12.TabIndex = 14;
            this.guna2HtmlLabel12.Text = "Account Overview";
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.guna2Button15);
            this.tabPage10.Controls.Add(this.guna2TextBox7);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel16);
            this.tabPage10.Controls.Add(this.guna2TextBox6);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel17);
            this.tabPage10.Controls.Add(this.guna2TextBox4);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel19);
            this.tabPage10.Controls.Add(this.guna2TextBox3);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel20);
            this.tabPage10.Controls.Add(this.guna2TextBox2);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel21);
            this.tabPage10.Controls.Add(this.guna2TextBox1);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel22);
            this.tabPage10.Controls.Add(this.guna2Button16);
            this.tabPage10.Controls.Add(this.label52);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel15);
            this.tabPage10.Controls.Add(this.guna2Button17);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(1134, 751);
            this.tabPage10.TabIndex = 5;
            this.tabPage10.Text = "tabPage10";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // guna2Button15
            // 
            this.guna2Button15.BackColor = System.Drawing.Color.White;
            this.guna2Button15.BorderRadius = 9;
            this.guna2Button15.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button15.CheckedState.Parent = this.guna2Button15;
            this.guna2Button15.CustomImages.Parent = this.guna2Button15;
            this.guna2Button15.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.guna2Button15.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button15.ForeColor = System.Drawing.Color.Black;
            this.guna2Button15.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button15.HoverState.Parent = this.guna2Button15;
            this.guna2Button15.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button15.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button15.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button15.Location = new System.Drawing.Point(28, 480);
            this.guna2Button15.Name = "guna2Button15";
            this.guna2Button15.PressedColor = System.Drawing.Color.White;
            this.guna2Button15.ShadowDecoration.Parent = this.guna2Button15;
            this.guna2Button15.Size = new System.Drawing.Size(208, 44);
            this.guna2Button15.TabIndex = 49;
            this.guna2Button15.Text = "Cancel";
            // 
            // guna2TextBox7
            // 
            this.guna2TextBox7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox7.BorderRadius = 6;
            this.guna2TextBox7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox7.DefaultText = "";
            this.guna2TextBox7.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox7.DisabledState.Parent = this.guna2TextBox7;
            this.guna2TextBox7.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox7.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox7.FocusedState.Parent = this.guna2TextBox7;
            this.guna2TextBox7.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox7.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox7.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox7.HoverState.Parent = this.guna2TextBox7;
            this.guna2TextBox7.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox7.Location = new System.Drawing.Point(525, 233);
            this.guna2TextBox7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox7.Name = "guna2TextBox7";
            this.guna2TextBox7.PasswordChar = '\0';
            this.guna2TextBox7.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox7.PlaceholderText = "Enter 4 digits pin";
            this.guna2TextBox7.SelectedText = "";
            this.guna2TextBox7.ShadowDecoration.Parent = this.guna2TextBox7;
            this.guna2TextBox7.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox7.TabIndex = 48;
            // 
            // guna2HtmlLabel16
            // 
            this.guna2HtmlLabel16.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel16.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel16.Location = new System.Drawing.Point(525, 205);
            this.guna2HtmlLabel16.Name = "guna2HtmlLabel16";
            this.guna2HtmlLabel16.Size = new System.Drawing.Size(27, 21);
            this.guna2HtmlLabel16.TabIndex = 47;
            this.guna2HtmlLabel16.Text = "Pin";
            // 
            // guna2TextBox6
            // 
            this.guna2TextBox6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox6.BorderRadius = 6;
            this.guna2TextBox6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox6.DefaultText = "";
            this.guna2TextBox6.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox6.DisabledState.Parent = this.guna2TextBox6;
            this.guna2TextBox6.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox6.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox6.FocusedState.Parent = this.guna2TextBox6;
            this.guna2TextBox6.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox6.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox6.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox6.HoverState.Parent = this.guna2TextBox6;
            this.guna2TextBox6.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox6.Location = new System.Drawing.Point(525, 140);
            this.guna2TextBox6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox6.Name = "guna2TextBox6";
            this.guna2TextBox6.PasswordChar = '\0';
            this.guna2TextBox6.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox6.PlaceholderText = "Enter account Id";
            this.guna2TextBox6.SelectedText = "";
            this.guna2TextBox6.ShadowDecoration.Parent = this.guna2TextBox6;
            this.guna2TextBox6.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox6.TabIndex = 46;
            // 
            // guna2HtmlLabel17
            // 
            this.guna2HtmlLabel17.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel17.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel17.Location = new System.Drawing.Point(525, 112);
            this.guna2HtmlLabel17.Name = "guna2HtmlLabel17";
            this.guna2HtmlLabel17.Size = new System.Drawing.Size(83, 21);
            this.guna2HtmlLabel17.TabIndex = 45;
            this.guna2HtmlLabel17.Text = "Account Id";
            // 
            // guna2TextBox4
            // 
            this.guna2TextBox4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox4.BorderRadius = 6;
            this.guna2TextBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox4.DefaultText = "";
            this.guna2TextBox4.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox4.DisabledState.Parent = this.guna2TextBox4;
            this.guna2TextBox4.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox4.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox4.FocusedState.Parent = this.guna2TextBox4;
            this.guna2TextBox4.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox4.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox4.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox4.HoverState.Parent = this.guna2TextBox4;
            this.guna2TextBox4.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox4.Location = new System.Drawing.Point(28, 411);
            this.guna2TextBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox4.Name = "guna2TextBox4";
            this.guna2TextBox4.PasswordChar = '\0';
            this.guna2TextBox4.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox4.PlaceholderText = "Enter password";
            this.guna2TextBox4.SelectedText = "";
            this.guna2TextBox4.ShadowDecoration.Parent = this.guna2TextBox4;
            this.guna2TextBox4.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox4.TabIndex = 42;
            // 
            // guna2HtmlLabel19
            // 
            this.guna2HtmlLabel19.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel19.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel19.Location = new System.Drawing.Point(28, 383);
            this.guna2HtmlLabel19.Name = "guna2HtmlLabel19";
            this.guna2HtmlLabel19.Size = new System.Drawing.Size(77, 21);
            this.guna2HtmlLabel19.TabIndex = 41;
            this.guna2HtmlLabel19.Text = "Password";
            // 
            // guna2TextBox3
            // 
            this.guna2TextBox3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.BorderRadius = 6;
            this.guna2TextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox3.DefaultText = "";
            this.guna2TextBox3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3.DisabledState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.FocusedState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox3.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox3.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.HoverState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox3.Location = new System.Drawing.Point(28, 322);
            this.guna2TextBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox3.Name = "guna2TextBox3";
            this.guna2TextBox3.PasswordChar = '\0';
            this.guna2TextBox3.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox3.PlaceholderText = "Enter email address";
            this.guna2TextBox3.SelectedText = "";
            this.guna2TextBox3.ShadowDecoration.Parent = this.guna2TextBox3;
            this.guna2TextBox3.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox3.TabIndex = 40;
            // 
            // guna2HtmlLabel20
            // 
            this.guna2HtmlLabel20.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel20.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel20.Location = new System.Drawing.Point(28, 294);
            this.guna2HtmlLabel20.Name = "guna2HtmlLabel20";
            this.guna2HtmlLabel20.Size = new System.Drawing.Size(108, 21);
            this.guna2HtmlLabel20.TabIndex = 39;
            this.guna2HtmlLabel20.Text = "Email Address";
            // 
            // guna2TextBox2
            // 
            this.guna2TextBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox2.BorderRadius = 6;
            this.guna2TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox2.DefaultText = "";
            this.guna2TextBox2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2.DisabledState.Parent = this.guna2TextBox2;
            this.guna2TextBox2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2.FocusedState.Parent = this.guna2TextBox2;
            this.guna2TextBox2.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox2.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2.HoverState.Parent = this.guna2TextBox2;
            this.guna2TextBox2.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox2.Location = new System.Drawing.Point(28, 229);
            this.guna2TextBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox2.Name = "guna2TextBox2";
            this.guna2TextBox2.PasswordChar = '\0';
            this.guna2TextBox2.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox2.PlaceholderText = "Enter username";
            this.guna2TextBox2.SelectedText = "";
            this.guna2TextBox2.ShadowDecoration.Parent = this.guna2TextBox2;
            this.guna2TextBox2.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox2.TabIndex = 38;
            // 
            // guna2HtmlLabel21
            // 
            this.guna2HtmlLabel21.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel21.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel21.Location = new System.Drawing.Point(28, 201);
            this.guna2HtmlLabel21.Name = "guna2HtmlLabel21";
            this.guna2HtmlLabel21.Size = new System.Drawing.Size(79, 21);
            this.guna2HtmlLabel21.TabIndex = 37;
            this.guna2HtmlLabel21.Text = "Username";
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.BorderRadius = 6;
            this.guna2TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1.DefaultText = "";
            this.guna2TextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.DisabledState.Parent = this.guna2TextBox1;
            this.guna2TextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.FocusedState.Parent = this.guna2TextBox1;
            this.guna2TextBox1.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox1.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.HoverState.Parent = this.guna2TextBox1;
            this.guna2TextBox1.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox1.Location = new System.Drawing.Point(28, 140);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.PasswordChar = '\0';
            this.guna2TextBox1.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox1.PlaceholderText = "Enter full name";
            this.guna2TextBox1.SelectedText = "";
            this.guna2TextBox1.ShadowDecoration.Parent = this.guna2TextBox1;
            this.guna2TextBox1.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox1.TabIndex = 36;
            // 
            // guna2HtmlLabel22
            // 
            this.guna2HtmlLabel22.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel22.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel22.Location = new System.Drawing.Point(28, 112);
            this.guna2HtmlLabel22.Name = "guna2HtmlLabel22";
            this.guna2HtmlLabel22.Size = new System.Drawing.Size(77, 21);
            this.guna2HtmlLabel22.TabIndex = 35;
            this.guna2HtmlLabel22.Text = "Full Name";
            // 
            // guna2Button16
            // 
            this.guna2Button16.BackColor = System.Drawing.Color.White;
            this.guna2Button16.BorderRadius = 9;
            this.guna2Button16.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button16.CheckedState.Parent = this.guna2Button16;
            this.guna2Button16.CustomImages.Parent = this.guna2Button16;
            this.guna2Button16.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button16.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button16.ForeColor = System.Drawing.Color.White;
            this.guna2Button16.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button16.HoverState.Parent = this.guna2Button16;
            this.guna2Button16.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button16.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button16.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button16.Location = new System.Drawing.Point(249, 480);
            this.guna2Button16.Name = "guna2Button16";
            this.guna2Button16.ShadowDecoration.Parent = this.guna2Button16;
            this.guna2Button16.Size = new System.Drawing.Size(208, 44);
            this.guna2Button16.TabIndex = 34;
            this.guna2Button16.Text = "Confirm";
            this.guna2Button16.Click += new System.EventHandler(this.Guna2Button16_Click);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Aileron Heavy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(24, 77);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(115, 19);
            this.label52.TabIndex = 28;
            this.label52.Text = "Profile Details";
            // 
            // guna2HtmlLabel15
            // 
            this.guna2HtmlLabel15.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel15.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel15.Location = new System.Drawing.Point(28, 31);
            this.guna2HtmlLabel15.Name = "guna2HtmlLabel15";
            this.guna2HtmlLabel15.Size = new System.Drawing.Size(187, 27);
            this.guna2HtmlLabel15.TabIndex = 27;
            this.guna2HtmlLabel15.Text = "Account Overview";
            // 
            // guna2Button17
            // 
            this.guna2Button17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button17.BackColor = System.Drawing.Color.White;
            this.guna2Button17.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button17.BorderRadius = 9;
            this.guna2Button17.BorderThickness = 1;
            this.guna2Button17.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button17.CheckedState.Parent = this.guna2Button17;
            this.guna2Button17.CustomImages.Parent = this.guna2Button17;
            this.guna2Button17.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button17.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button17.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button17.HoverState.Parent = this.guna2Button17;
            this.guna2Button17.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button17.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button17.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button17.Location = new System.Drawing.Point(962, 40);
            this.guna2Button17.Name = "guna2Button17";
            this.guna2Button17.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button17.ShadowDecoration.Parent = this.guna2Button17;
            this.guna2Button17.Size = new System.Drawing.Size(134, 34);
            this.guna2Button17.TabIndex = 26;
            this.guna2Button17.Text = "Edit Account";
            // 
            // tabPage6
            // 
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1134, 751);
            this.tabPage6.TabIndex = 6;
            this.tabPage6.Text = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.guna2Button18);
            this.tabPage7.Controls.Add(this.guna2TextBox9);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel3);
            this.tabPage7.Controls.Add(this.guna2TextBox10);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel10);
            this.tabPage7.Controls.Add(this.guna2TextBox12);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel8);
            this.tabPage7.Controls.Add(this.guna2TextBox13);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel5);
            this.tabPage7.Controls.Add(this.guna2TextBox14);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel13);
            this.tabPage7.Controls.Add(this.guna2TextBox15);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel14);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel23);
            this.tabPage7.Controls.Add(this.guna2Button19);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel24);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(1134, 751);
            this.tabPage7.TabIndex = 7;
            this.tabPage7.Text = "tabPage7";
            this.tabPage7.UseVisualStyleBackColor = true;
            this.tabPage7.Click += new System.EventHandler(this.TabPage7_Click);
            // 
            // guna2Button18
            // 
            this.guna2Button18.BackColor = System.Drawing.Color.White;
            this.guna2Button18.BorderRadius = 9;
            this.guna2Button18.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button18.CheckedState.Parent = this.guna2Button18;
            this.guna2Button18.CustomImages.Parent = this.guna2Button18;
            this.guna2Button18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.guna2Button18.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button18.ForeColor = System.Drawing.Color.Black;
            this.guna2Button18.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button18.HoverState.Parent = this.guna2Button18;
            this.guna2Button18.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button18.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button18.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button18.Location = new System.Drawing.Point(33, 481);
            this.guna2Button18.Name = "guna2Button18";
            this.guna2Button18.PressedColor = System.Drawing.Color.White;
            this.guna2Button18.ShadowDecoration.Parent = this.guna2Button18;
            this.guna2Button18.Size = new System.Drawing.Size(208, 44);
            this.guna2Button18.TabIndex = 51;
            this.guna2Button18.Text = "Cancel";
            this.guna2Button18.Click += new System.EventHandler(this.Guna2Button18_Click);
            // 
            // guna2TextBox9
            // 
            this.guna2TextBox9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox9.BorderRadius = 6;
            this.guna2TextBox9.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox9.DefaultText = "";
            this.guna2TextBox9.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox9.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox9.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox9.DisabledState.Parent = this.guna2TextBox9;
            this.guna2TextBox9.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox9.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox9.FocusedState.Parent = this.guna2TextBox9;
            this.guna2TextBox9.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox9.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox9.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox9.HoverState.Parent = this.guna2TextBox9;
            this.guna2TextBox9.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox9.Location = new System.Drawing.Point(532, 230);
            this.guna2TextBox9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox9.Name = "guna2TextBox9";
            this.guna2TextBox9.PasswordChar = '\0';
            this.guna2TextBox9.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox9.PlaceholderText = "Enter 4 digits pin";
            this.guna2TextBox9.SelectedText = "";
            this.guna2TextBox9.ShadowDecoration.Parent = this.guna2TextBox9;
            this.guna2TextBox9.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox9.TabIndex = 50;
            this.guna2TextBox9.TextChanged += new System.EventHandler(this.Guna2TextBox9_TextChanged);
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(532, 202);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(27, 21);
            this.guna2HtmlLabel3.TabIndex = 49;
            this.guna2HtmlLabel3.Text = "Pin";
            this.guna2HtmlLabel3.Click += new System.EventHandler(this.Guna2HtmlLabel3_Click);
            // 
            // guna2TextBox10
            // 
            this.guna2TextBox10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(182)))), ((int)(((byte)(182)))));
            this.guna2TextBox10.BorderRadius = 6;
            this.guna2TextBox10.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox10.DefaultText = "";
            this.guna2TextBox10.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox10.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox10.DisabledState.Parent = this.guna2TextBox10;
            this.guna2TextBox10.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox10.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox10.FocusedState.Parent = this.guna2TextBox10;
            this.guna2TextBox10.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox10.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox10.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox10.HoverState.Parent = this.guna2TextBox10;
            this.guna2TextBox10.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox10.Location = new System.Drawing.Point(532, 141);
            this.guna2TextBox10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox10.Name = "guna2TextBox10";
            this.guna2TextBox10.PasswordChar = '\0';
            this.guna2TextBox10.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox10.PlaceholderText = "Auto generated Id 63200+";
            this.guna2TextBox10.ReadOnly = true;
            this.guna2TextBox10.SelectedText = "";
            this.guna2TextBox10.ShadowDecoration.Parent = this.guna2TextBox10;
            this.guna2TextBox10.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox10.TabIndex = 48;
            this.guna2TextBox10.TextChanged += new System.EventHandler(this.Guna2TextBox10_TextChanged);
            // 
            // guna2HtmlLabel10
            // 
            this.guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel10.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel10.Location = new System.Drawing.Point(532, 113);
            this.guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            this.guna2HtmlLabel10.Size = new System.Drawing.Size(83, 21);
            this.guna2HtmlLabel10.TabIndex = 47;
            this.guna2HtmlLabel10.Text = "Account Id";
            this.guna2HtmlLabel10.Click += new System.EventHandler(this.Guna2HtmlLabel10_Click);
            // 
            // guna2TextBox12
            // 
            this.guna2TextBox12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox12.BorderRadius = 6;
            this.guna2TextBox12.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox12.DefaultText = "";
            this.guna2TextBox12.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox12.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox12.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox12.DisabledState.Parent = this.guna2TextBox12;
            this.guna2TextBox12.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox12.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox12.FocusedState.Parent = this.guna2TextBox12;
            this.guna2TextBox12.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox12.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox12.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox12.HoverState.Parent = this.guna2TextBox12;
            this.guna2TextBox12.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox12.Location = new System.Drawing.Point(33, 412);
            this.guna2TextBox12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox12.Name = "guna2TextBox12";
            this.guna2TextBox12.PasswordChar = '\0';
            this.guna2TextBox12.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox12.PlaceholderText = "Enter password";
            this.guna2TextBox12.SelectedText = "";
            this.guna2TextBox12.ShadowDecoration.Parent = this.guna2TextBox12;
            this.guna2TextBox12.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox12.TabIndex = 44;
            this.guna2TextBox12.TextChanged += new System.EventHandler(this.Guna2TextBox12_TextChanged);
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(33, 384);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(77, 21);
            this.guna2HtmlLabel8.TabIndex = 43;
            this.guna2HtmlLabel8.Text = "Password";
            this.guna2HtmlLabel8.Click += new System.EventHandler(this.Guna2HtmlLabel8_Click);
            // 
            // guna2TextBox13
            // 
            this.guna2TextBox13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox13.BorderRadius = 6;
            this.guna2TextBox13.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox13.DefaultText = "";
            this.guna2TextBox13.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox13.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox13.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox13.DisabledState.Parent = this.guna2TextBox13;
            this.guna2TextBox13.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox13.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox13.FocusedState.Parent = this.guna2TextBox13;
            this.guna2TextBox13.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox13.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox13.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox13.HoverState.Parent = this.guna2TextBox13;
            this.guna2TextBox13.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox13.Location = new System.Drawing.Point(33, 323);
            this.guna2TextBox13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox13.Name = "guna2TextBox13";
            this.guna2TextBox13.PasswordChar = '\0';
            this.guna2TextBox13.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox13.PlaceholderText = "Enter email address";
            this.guna2TextBox13.SelectedText = "";
            this.guna2TextBox13.ShadowDecoration.Parent = this.guna2TextBox13;
            this.guna2TextBox13.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox13.TabIndex = 42;
            this.guna2TextBox13.TextChanged += new System.EventHandler(this.Guna2TextBox13_TextChanged);
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(33, 295);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(108, 21);
            this.guna2HtmlLabel5.TabIndex = 41;
            this.guna2HtmlLabel5.Text = "Email Address";
            this.guna2HtmlLabel5.Click += new System.EventHandler(this.Guna2HtmlLabel5_Click);
            // 
            // guna2TextBox14
            // 
            this.guna2TextBox14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox14.BorderRadius = 6;
            this.guna2TextBox14.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox14.DefaultText = "";
            this.guna2TextBox14.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox14.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox14.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox14.DisabledState.Parent = this.guna2TextBox14;
            this.guna2TextBox14.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox14.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox14.FocusedState.Parent = this.guna2TextBox14;
            this.guna2TextBox14.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox14.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox14.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox14.HoverState.Parent = this.guna2TextBox14;
            this.guna2TextBox14.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox14.Location = new System.Drawing.Point(33, 230);
            this.guna2TextBox14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox14.Name = "guna2TextBox14";
            this.guna2TextBox14.PasswordChar = '\0';
            this.guna2TextBox14.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox14.PlaceholderText = "Enter username";
            this.guna2TextBox14.SelectedText = "";
            this.guna2TextBox14.ShadowDecoration.Parent = this.guna2TextBox14;
            this.guna2TextBox14.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox14.TabIndex = 40;
            this.guna2TextBox14.TextChanged += new System.EventHandler(this.Guna2TextBox14_TextChanged);
            // 
            // guna2HtmlLabel13
            // 
            this.guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel13.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel13.Location = new System.Drawing.Point(33, 202);
            this.guna2HtmlLabel13.Name = "guna2HtmlLabel13";
            this.guna2HtmlLabel13.Size = new System.Drawing.Size(79, 21);
            this.guna2HtmlLabel13.TabIndex = 39;
            this.guna2HtmlLabel13.Text = "Username";
            this.guna2HtmlLabel13.Click += new System.EventHandler(this.Guna2HtmlLabel13_Click);
            // 
            // guna2TextBox15
            // 
            this.guna2TextBox15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox15.BorderRadius = 6;
            this.guna2TextBox15.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox15.DefaultText = "";
            this.guna2TextBox15.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox15.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox15.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox15.DisabledState.Parent = this.guna2TextBox15;
            this.guna2TextBox15.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox15.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox15.FocusedState.Parent = this.guna2TextBox15;
            this.guna2TextBox15.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox15.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox15.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox15.HoverState.Parent = this.guna2TextBox15;
            this.guna2TextBox15.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox15.Location = new System.Drawing.Point(33, 141);
            this.guna2TextBox15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox15.Name = "guna2TextBox15";
            this.guna2TextBox15.PasswordChar = '\0';
            this.guna2TextBox15.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox15.PlaceholderText = "Enter full name";
            this.guna2TextBox15.SelectedText = "";
            this.guna2TextBox15.ShadowDecoration.Parent = this.guna2TextBox15;
            this.guna2TextBox15.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox15.TabIndex = 38;
            this.guna2TextBox15.TextChanged += new System.EventHandler(this.Guna2TextBox15_TextChanged);
            // 
            // guna2HtmlLabel14
            // 
            this.guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel14.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel14.Location = new System.Drawing.Point(33, 113);
            this.guna2HtmlLabel14.Name = "guna2HtmlLabel14";
            this.guna2HtmlLabel14.Size = new System.Drawing.Size(77, 21);
            this.guna2HtmlLabel14.TabIndex = 37;
            this.guna2HtmlLabel14.Text = "Full Name";
            this.guna2HtmlLabel14.Click += new System.EventHandler(this.Guna2HtmlLabel14_Click);
            // 
            // guna2HtmlLabel23
            // 
            this.guna2HtmlLabel23.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel23.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel23.Location = new System.Drawing.Point(33, 73);
            this.guna2HtmlLabel23.Name = "guna2HtmlLabel23";
            this.guna2HtmlLabel23.Size = new System.Drawing.Size(106, 21);
            this.guna2HtmlLabel23.TabIndex = 36;
            this.guna2HtmlLabel23.Text = "Profile Details";
            this.guna2HtmlLabel23.Click += new System.EventHandler(this.Guna2HtmlLabel23_Click);
            // 
            // guna2Button19
            // 
            this.guna2Button19.BackColor = System.Drawing.Color.White;
            this.guna2Button19.BorderRadius = 9;
            this.guna2Button19.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button19.CheckedState.Parent = this.guna2Button19;
            this.guna2Button19.CustomImages.Parent = this.guna2Button19;
            this.guna2Button19.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button19.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button19.ForeColor = System.Drawing.Color.White;
            this.guna2Button19.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button19.HoverState.Parent = this.guna2Button19;
            this.guna2Button19.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button19.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button19.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button19.Location = new System.Drawing.Point(254, 481);
            this.guna2Button19.Name = "guna2Button19";
            this.guna2Button19.ShadowDecoration.Parent = this.guna2Button19;
            this.guna2Button19.Size = new System.Drawing.Size(208, 44);
            this.guna2Button19.TabIndex = 35;
            this.guna2Button19.Text = "Confirm";
            this.guna2Button19.Click += new System.EventHandler(this.Guna2Button19_Click);
            // 
            // guna2HtmlLabel24
            // 
            this.guna2HtmlLabel24.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel24.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel24.Location = new System.Drawing.Point(33, 34);
            this.guna2HtmlLabel24.Name = "guna2HtmlLabel24";
            this.guna2HtmlLabel24.Size = new System.Drawing.Size(184, 27);
            this.guna2HtmlLabel24.TabIndex = 34;
            this.guna2HtmlLabel24.Text = "Create new admin";
            this.guna2HtmlLabel24.Click += new System.EventHandler(this.Guna2HtmlLabel24_Click);
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.guna2Button20);
            this.tabPage8.Controls.Add(this.guna2TextBox16);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel25);
            this.tabPage8.Controls.Add(this.guna2TextBox17);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel26);
            this.tabPage8.Controls.Add(this.guna2TextBox19);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel28);
            this.tabPage8.Controls.Add(this.guna2TextBox20);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel29);
            this.tabPage8.Controls.Add(this.guna2TextBox21);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel30);
            this.tabPage8.Controls.Add(this.guna2TextBox22);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel31);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel32);
            this.tabPage8.Controls.Add(this.guna2Button21);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel33);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(1134, 751);
            this.tabPage8.TabIndex = 8;
            this.tabPage8.Text = "tabPage8";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // guna2Button20
            // 
            this.guna2Button20.BackColor = System.Drawing.Color.White;
            this.guna2Button20.BorderRadius = 9;
            this.guna2Button20.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button20.CheckedState.Parent = this.guna2Button20;
            this.guna2Button20.CustomImages.Parent = this.guna2Button20;
            this.guna2Button20.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.guna2Button20.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button20.ForeColor = System.Drawing.Color.Black;
            this.guna2Button20.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button20.HoverState.Parent = this.guna2Button20;
            this.guna2Button20.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button20.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button20.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button20.Location = new System.Drawing.Point(26, 477);
            this.guna2Button20.Name = "guna2Button20";
            this.guna2Button20.PressedColor = System.Drawing.Color.White;
            this.guna2Button20.ShadowDecoration.Parent = this.guna2Button20;
            this.guna2Button20.Size = new System.Drawing.Size(208, 44);
            this.guna2Button20.TabIndex = 69;
            this.guna2Button20.Text = "Cancel";
            this.guna2Button20.Click += new System.EventHandler(this.Guna2Button20_Click);
            // 
            // guna2TextBox16
            // 
            this.guna2TextBox16.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox16.BorderRadius = 6;
            this.guna2TextBox16.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox16.DefaultText = "";
            this.guna2TextBox16.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox16.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox16.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox16.DisabledState.Parent = this.guna2TextBox16;
            this.guna2TextBox16.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox16.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox16.FocusedState.Parent = this.guna2TextBox16;
            this.guna2TextBox16.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox16.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox16.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox16.HoverState.Parent = this.guna2TextBox16;
            this.guna2TextBox16.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox16.Location = new System.Drawing.Point(524, 226);
            this.guna2TextBox16.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox16.Name = "guna2TextBox16";
            this.guna2TextBox16.PasswordChar = '\0';
            this.guna2TextBox16.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox16.PlaceholderText = "Enter 4 digits pin";
            this.guna2TextBox16.SelectedText = "";
            this.guna2TextBox16.ShadowDecoration.Parent = this.guna2TextBox16;
            this.guna2TextBox16.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox16.TabIndex = 68;
            // 
            // guna2HtmlLabel25
            // 
            this.guna2HtmlLabel25.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel25.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel25.Location = new System.Drawing.Point(524, 198);
            this.guna2HtmlLabel25.Name = "guna2HtmlLabel25";
            this.guna2HtmlLabel25.Size = new System.Drawing.Size(27, 21);
            this.guna2HtmlLabel25.TabIndex = 67;
            this.guna2HtmlLabel25.Text = "Pin";
            // 
            // guna2TextBox17
            // 
            this.guna2TextBox17.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(182)))), ((int)(((byte)(182)))));
            this.guna2TextBox17.BorderRadius = 6;
            this.guna2TextBox17.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox17.DefaultText = "";
            this.guna2TextBox17.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox17.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox17.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox17.DisabledState.Parent = this.guna2TextBox17;
            this.guna2TextBox17.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox17.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox17.FocusedState.Parent = this.guna2TextBox17;
            this.guna2TextBox17.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox17.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox17.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox17.HoverState.Parent = this.guna2TextBox17;
            this.guna2TextBox17.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox17.Location = new System.Drawing.Point(524, 133);
            this.guna2TextBox17.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox17.Name = "guna2TextBox17";
            this.guna2TextBox17.PasswordChar = '\0';
            this.guna2TextBox17.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox17.PlaceholderText = "Auto generated Id 63200+";
            this.guna2TextBox17.ReadOnly = true;
            this.guna2TextBox17.SelectedText = "";
            this.guna2TextBox17.ShadowDecoration.Parent = this.guna2TextBox17;
            this.guna2TextBox17.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox17.TabIndex = 66;
            // 
            // guna2HtmlLabel26
            // 
            this.guna2HtmlLabel26.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel26.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel26.Location = new System.Drawing.Point(524, 105);
            this.guna2HtmlLabel26.Name = "guna2HtmlLabel26";
            this.guna2HtmlLabel26.Size = new System.Drawing.Size(83, 21);
            this.guna2HtmlLabel26.TabIndex = 65;
            this.guna2HtmlLabel26.Text = "Account Id";
            // 
            // guna2TextBox19
            // 
            this.guna2TextBox19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox19.BorderRadius = 6;
            this.guna2TextBox19.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox19.DefaultText = "";
            this.guna2TextBox19.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox19.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox19.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox19.DisabledState.Parent = this.guna2TextBox19;
            this.guna2TextBox19.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox19.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox19.FocusedState.Parent = this.guna2TextBox19;
            this.guna2TextBox19.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox19.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox19.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox19.HoverState.Parent = this.guna2TextBox19;
            this.guna2TextBox19.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox19.Location = new System.Drawing.Point(26, 408);
            this.guna2TextBox19.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox19.Name = "guna2TextBox19";
            this.guna2TextBox19.PasswordChar = '\0';
            this.guna2TextBox19.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox19.PlaceholderText = "Enter password";
            this.guna2TextBox19.SelectedText = "";
            this.guna2TextBox19.ShadowDecoration.Parent = this.guna2TextBox19;
            this.guna2TextBox19.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox19.TabIndex = 62;
            // 
            // guna2HtmlLabel28
            // 
            this.guna2HtmlLabel28.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel28.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel28.Location = new System.Drawing.Point(26, 380);
            this.guna2HtmlLabel28.Name = "guna2HtmlLabel28";
            this.guna2HtmlLabel28.Size = new System.Drawing.Size(77, 21);
            this.guna2HtmlLabel28.TabIndex = 61;
            this.guna2HtmlLabel28.Text = "Password";
            // 
            // guna2TextBox20
            // 
            this.guna2TextBox20.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox20.BorderRadius = 6;
            this.guna2TextBox20.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox20.DefaultText = "";
            this.guna2TextBox20.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox20.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox20.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox20.DisabledState.Parent = this.guna2TextBox20;
            this.guna2TextBox20.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox20.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox20.FocusedState.Parent = this.guna2TextBox20;
            this.guna2TextBox20.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox20.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox20.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox20.HoverState.Parent = this.guna2TextBox20;
            this.guna2TextBox20.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox20.Location = new System.Drawing.Point(26, 319);
            this.guna2TextBox20.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox20.Name = "guna2TextBox20";
            this.guna2TextBox20.PasswordChar = '\0';
            this.guna2TextBox20.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox20.PlaceholderText = "Enter email address";
            this.guna2TextBox20.SelectedText = "";
            this.guna2TextBox20.ShadowDecoration.Parent = this.guna2TextBox20;
            this.guna2TextBox20.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox20.TabIndex = 60;
            // 
            // guna2HtmlLabel29
            // 
            this.guna2HtmlLabel29.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel29.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel29.Location = new System.Drawing.Point(26, 291);
            this.guna2HtmlLabel29.Name = "guna2HtmlLabel29";
            this.guna2HtmlLabel29.Size = new System.Drawing.Size(108, 21);
            this.guna2HtmlLabel29.TabIndex = 59;
            this.guna2HtmlLabel29.Text = "Email Address";
            // 
            // guna2TextBox21
            // 
            this.guna2TextBox21.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox21.BorderRadius = 6;
            this.guna2TextBox21.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox21.DefaultText = "";
            this.guna2TextBox21.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox21.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox21.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox21.DisabledState.Parent = this.guna2TextBox21;
            this.guna2TextBox21.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox21.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox21.FocusedState.Parent = this.guna2TextBox21;
            this.guna2TextBox21.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox21.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox21.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox21.HoverState.Parent = this.guna2TextBox21;
            this.guna2TextBox21.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox21.Location = new System.Drawing.Point(26, 226);
            this.guna2TextBox21.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox21.Name = "guna2TextBox21";
            this.guna2TextBox21.PasswordChar = '\0';
            this.guna2TextBox21.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox21.PlaceholderText = "Enter username";
            this.guna2TextBox21.SelectedText = "";
            this.guna2TextBox21.ShadowDecoration.Parent = this.guna2TextBox21;
            this.guna2TextBox21.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox21.TabIndex = 58;
            // 
            // guna2HtmlLabel30
            // 
            this.guna2HtmlLabel30.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel30.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel30.Location = new System.Drawing.Point(26, 198);
            this.guna2HtmlLabel30.Name = "guna2HtmlLabel30";
            this.guna2HtmlLabel30.Size = new System.Drawing.Size(79, 21);
            this.guna2HtmlLabel30.TabIndex = 57;
            this.guna2HtmlLabel30.Text = "Username";
            // 
            // guna2TextBox22
            // 
            this.guna2TextBox22.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox22.BorderRadius = 6;
            this.guna2TextBox22.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox22.DefaultText = "";
            this.guna2TextBox22.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox22.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox22.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox22.DisabledState.Parent = this.guna2TextBox22;
            this.guna2TextBox22.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox22.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox22.FocusedState.Parent = this.guna2TextBox22;
            this.guna2TextBox22.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox22.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox22.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox22.HoverState.Parent = this.guna2TextBox22;
            this.guna2TextBox22.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox22.Location = new System.Drawing.Point(26, 137);
            this.guna2TextBox22.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox22.Name = "guna2TextBox22";
            this.guna2TextBox22.PasswordChar = '\0';
            this.guna2TextBox22.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox22.PlaceholderText = "Enter full name";
            this.guna2TextBox22.SelectedText = "";
            this.guna2TextBox22.ShadowDecoration.Parent = this.guna2TextBox22;
            this.guna2TextBox22.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox22.TabIndex = 56;
            // 
            // guna2HtmlLabel31
            // 
            this.guna2HtmlLabel31.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel31.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel31.Location = new System.Drawing.Point(26, 109);
            this.guna2HtmlLabel31.Name = "guna2HtmlLabel31";
            this.guna2HtmlLabel31.Size = new System.Drawing.Size(77, 21);
            this.guna2HtmlLabel31.TabIndex = 55;
            this.guna2HtmlLabel31.Text = "Full Name";
            // 
            // guna2HtmlLabel32
            // 
            this.guna2HtmlLabel32.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel32.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel32.Location = new System.Drawing.Point(26, 69);
            this.guna2HtmlLabel32.Name = "guna2HtmlLabel32";
            this.guna2HtmlLabel32.Size = new System.Drawing.Size(106, 21);
            this.guna2HtmlLabel32.TabIndex = 54;
            this.guna2HtmlLabel32.Text = "Profile Details";
            // 
            // guna2Button21
            // 
            this.guna2Button21.BackColor = System.Drawing.Color.White;
            this.guna2Button21.BorderRadius = 9;
            this.guna2Button21.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button21.CheckedState.Parent = this.guna2Button21;
            this.guna2Button21.CustomImages.Parent = this.guna2Button21;
            this.guna2Button21.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button21.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button21.ForeColor = System.Drawing.Color.White;
            this.guna2Button21.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button21.HoverState.Parent = this.guna2Button21;
            this.guna2Button21.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button21.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button21.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button21.Location = new System.Drawing.Point(247, 477);
            this.guna2Button21.Name = "guna2Button21";
            this.guna2Button21.ShadowDecoration.Parent = this.guna2Button21;
            this.guna2Button21.Size = new System.Drawing.Size(208, 44);
            this.guna2Button21.TabIndex = 53;
            this.guna2Button21.Text = "Confirm";
            this.guna2Button21.Click += new System.EventHandler(this.Guna2Button21_Click);
            // 
            // guna2HtmlLabel33
            // 
            this.guna2HtmlLabel33.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel33.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel33.Location = new System.Drawing.Point(26, 30);
            this.guna2HtmlLabel33.Name = "guna2HtmlLabel33";
            this.guna2HtmlLabel33.Size = new System.Drawing.Size(113, 27);
            this.guna2HtmlLabel33.TabIndex = 52;
            this.guna2HtmlLabel33.Text = "Edit Profile";
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel3.BackColor = System.Drawing.Color.White;
            this.guna2Panel3.BorderRadius = 9;
            this.guna2Panel3.Controls.Add(this.guna2PictureBox4);
            this.guna2Panel3.Controls.Add(this.guna2PictureBox7);
            this.guna2Panel3.Controls.Add(this.guna2HtmlLabel4);
            this.guna2Panel3.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.ShadowDecoration.Parent = this.guna2Panel3;
            this.guna2Panel3.Size = new System.Drawing.Size(1197, 51);
            this.guna2Panel3.TabIndex = 16;
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.guna2PictureBox4.Image = global::viewminder1.Properties.Resources.notifications;
            this.guna2PictureBox4.Location = new System.Drawing.Point(1101, 12);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.ShadowDecoration.Parent = this.guna2PictureBox4;
            this.guna2PictureBox4.Size = new System.Drawing.Size(24, 24);
            this.guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox4.TabIndex = 6;
            this.guna2PictureBox4.TabStop = false;
            // 
            // guna2PictureBox7
            // 
            this.guna2PictureBox7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.guna2PictureBox7.Image = global::viewminder1.Properties.Resources.profile;
            this.guna2PictureBox7.Location = new System.Drawing.Point(1143, 12);
            this.guna2PictureBox7.Name = "guna2PictureBox7";
            this.guna2PictureBox7.ShadowDecoration.Parent = this.guna2PictureBox7;
            this.guna2PictureBox7.Size = new System.Drawing.Size(24, 24);
            this.guna2PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox7.TabIndex = 5;
            this.guna2PictureBox7.TabStop = false;
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Aileron SemiBold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(25, 12);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(318, 31);
            this.guna2HtmlLabel4.TabIndex = 3;
            this.guna2HtmlLabel4.Text = "Welcome back Super Admin!";
            // 
            // login1TableAdapter
            // 
            this.login1TableAdapter.ClearBeforeFill = true;
            // 
            // usernameDataGridViewTextBoxColumn1
            // 
            this.usernameDataGridViewTextBoxColumn1.DataPropertyName = "username";
            this.usernameDataGridViewTextBoxColumn1.HeaderText = "username";
            this.usernameDataGridViewTextBoxColumn1.Name = "usernameDataGridViewTextBoxColumn1";
            this.usernameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // passwordDataGridViewTextBoxColumn1
            // 
            this.passwordDataGridViewTextBoxColumn1.DataPropertyName = "password";
            this.passwordDataGridViewTextBoxColumn1.HeaderText = "password";
            this.passwordDataGridViewTextBoxColumn1.Name = "passwordDataGridViewTextBoxColumn1";
            this.passwordDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "id";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            this.idDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // fullNameDataGridViewTextBoxColumn1
            // 
            this.fullNameDataGridViewTextBoxColumn1.DataPropertyName = "fullName";
            this.fullNameDataGridViewTextBoxColumn1.HeaderText = "fullName";
            this.fullNameDataGridViewTextBoxColumn1.Name = "fullNameDataGridViewTextBoxColumn1";
            this.fullNameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // emailDataGridViewTextBoxColumn1
            // 
            this.emailDataGridViewTextBoxColumn1.DataPropertyName = "email";
            this.emailDataGridViewTextBoxColumn1.HeaderText = "email";
            this.emailDataGridViewTextBoxColumn1.Name = "emailDataGridViewTextBoxColumn1";
            this.emailDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // pinDataGridViewTextBoxColumn1
            // 
            this.pinDataGridViewTextBoxColumn1.DataPropertyName = "pin";
            this.pinDataGridViewTextBoxColumn1.HeaderText = "pin";
            this.pinDataGridViewTextBoxColumn1.Name = "pinDataGridViewTextBoxColumn1";
            this.pinDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // superAdmn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1473, 858);
            this.Controls.Add(this.pnlContent);
            this.Controls.Add(this.btnPanel);
            this.Controls.Add(this.guna2Panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "superAdmn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "superAdmn";
            this.Load += new System.EventHandler(this.SuperAdmn_Load);
            this.guna2Panel2.ResumeLayout(false);
            this.btnPanel.ResumeLayout(false);
            this.btnPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.pnlContent.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.login1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.adminDataSet)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.guna2Panel7.ResumeLayout(false);
            this.guna2Panel7.PerformLayout();
            this.guna2Panel11.ResumeLayout(false);
            this.guna2Panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.guna2Panel8.ResumeLayout(false);
            this.guna2Panel8.PerformLayout();
            this.guna2Panel12.ResumeLayout(false);
            this.guna2Panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.guna2Panel9.ResumeLayout(false);
            this.guna2Panel9.PerformLayout();
            this.guna2Panel13.ResumeLayout(false);
            this.guna2Panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.guna2Panel3.ResumeLayout(false);
            this.guna2Panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox3;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox2;
        private Guna.UI2.WinForms.Guna2Panel btnPanel;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button btnArchive;
        private Guna.UI2.WinForms.Guna2Button btnSms;
        private Guna.UI2.WinForms.Guna2Button btnWatching;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2Panel pnlContent;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private Guna.UI2.WinForms.Guna2Button guna2Button9;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel7;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox16;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox13;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox11;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private System.Windows.Forms.TabPage tabPage3;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button10;
        private Guna.UI2.WinForms.Guna2Button guna2Button11;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel8;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel12;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.PictureBox pictureBox21;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator7;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox18;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox12;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator3;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private System.Windows.Forms.TabPage tabPage4;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button guna2Button12;
        private Guna.UI2.WinForms.Guna2Button guna2Button13;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel9;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel13;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox pictureBox24;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator8;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.PictureBox pictureBox26;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator9;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox pictureBox27;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator10;
        private System.Windows.Forms.Label label33;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel11;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private Guna.UI2.WinForms.Guna2Button guna2Button14;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel12;
        private System.Windows.Forms.TabPage tabPage10;
        private Guna.UI2.WinForms.Guna2Button guna2Button15;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel16;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel17;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel19;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel20;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel21;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel22;
        private Guna.UI2.WinForms.Guna2Button guna2Button16;
        private System.Windows.Forms.Label label52;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel15;
        private Guna.UI2.WinForms.Guna2Button guna2Button17;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button24;
        private Guna.UI2.WinForms.Guna2Button guna2Button25;
        private Guna.UI2.WinForms.Guna2Button guna2Button26;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox8;
        private System.Windows.Forms.TabPage tabPage6;
        private AdminDataSet adminDataSet;
        private System.Windows.Forms.BindingSource login1BindingSource;
        private AdminDataSetTableAdapters.login1TableAdapter login1TableAdapter;
        private System.Windows.Forms.TabPage tabPage7;
        private Guna.UI2.WinForms.Guna2Button guna2Button18;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox9;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox10;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox12;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox13;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox14;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel13;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox15;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel14;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel23;
        private Guna.UI2.WinForms.Guna2Button guna2Button19;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel24;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView1;
        private System.Windows.Forms.TabPage tabPage8;
        private Guna.UI2.WinForms.Guna2Button guna2Button20;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox16;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel25;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox17;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel26;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox19;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel28;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox20;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel29;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox21;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel30;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox22;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel31;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel32;
        private Guna.UI2.WinForms.Guna2Button guna2Button21;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel33;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn fullNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pinDataGridViewTextBoxColumn1;
    }
}