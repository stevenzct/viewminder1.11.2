﻿namespace viewminder1
{


    partial class AdminDataSet
    {
    }
}

